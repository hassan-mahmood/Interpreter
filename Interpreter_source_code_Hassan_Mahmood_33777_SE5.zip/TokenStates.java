package Interpreter;

public enum TokenStates {		//THese can be the token states, 
DEFAULT, OPERATOR, NUMBER, KEYWORD,STRING,
}
